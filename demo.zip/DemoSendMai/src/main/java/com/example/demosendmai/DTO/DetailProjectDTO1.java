package com.example.demosendmai.DTO;

import lombok.Data;

@Data
public class DetailProjectDTO1 {
    private String projectName;
    private String evaluationPerson;
    private String assessedPerson;


}
