package com.example.demosendmai.DTO;

import lombok.Data;

import java.util.List;

@Data
public class ListEvaluationDetailProjectDTO {
    private String projectName;
    private List<ListEmailReceiverDTO1> evaluationPersonOfProject;
    private List<ListEmailReceiverDTO2> assessedPersonOfProject;
}
