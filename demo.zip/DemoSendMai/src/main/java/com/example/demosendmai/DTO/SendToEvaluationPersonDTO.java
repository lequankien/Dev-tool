package com.example.demosendmai.DTO;

import lombok.Data;
import org.hibernate.sql.OracleJoinFragment;

import java.time.Instant;
import java.util.List;

@Data
public class SendToEvaluationPersonDTO {

    private String evaluationDepartment;

    private String evaluationDepartmentName;

    private String assessedDepartment;

    private String assessedDepartmentName;

    private List<ListEmailReceiverDTO1> evaluationPerson;

    private List<ListEmailReceiverDTO2> assessedPerson;

    private String evaluationType;

    private String evaluationName;

    private String dueDate;

    private String description;

   private List<ListEvaluationDetailProjectDTO> evaluationDetailProject;

    public String getEvaluationDepartment() {
        return evaluationDepartment;
    }

    public void setEvaluationDepartment(String evaluationDepartment) {
        this.evaluationDepartment = evaluationDepartment;
    }

    public String getEvaluationDepartmentName() {
        return evaluationDepartmentName;
    }

    public void setEvaluationDepartmentName(String evaluationDepartmentName) {
        this.evaluationDepartmentName = evaluationDepartmentName;
    }

    public String getAssessedDepartment() {
        return assessedDepartment;
    }

    public void setAssessedDepartment(String assessedDepartment) {
        this.assessedDepartment = assessedDepartment;
    }

    public String getAssessedDepartmentName() {
        return assessedDepartmentName;
    }

    public void setAssessedDepartmentName(String assessedDepartmentName) {
        this.assessedDepartmentName = assessedDepartmentName;
    }

    public List<ListEmailReceiverDTO1> getEvaluationPerson() {
        return evaluationPerson;
    }

    public void setEvaluationPerson(List<ListEmailReceiverDTO1> evaluationPerson) {
        this.evaluationPerson = evaluationPerson;
    }

    public List<ListEmailReceiverDTO2> getAssessedPerson() {
        return assessedPerson;
    }

    public void setAssessedPerson(List<ListEmailReceiverDTO2> assessedPerson) {
        this.assessedPerson = assessedPerson;
    }

    public String getEvaluationType() {
        return evaluationType;
    }

    public void setEvaluationType(String evaluationType) {
        this.evaluationType = evaluationType;
    }

    public String getEvaluationName() {
        return evaluationName;
    }

    public void setEvaluationName(String evaluationName) {
        this.evaluationName = evaluationName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<ListEvaluationDetailProjectDTO> getEvaluationDetailProject() {
        return evaluationDetailProject;
    }

    public void setEvaluationDetailProject(List<ListEvaluationDetailProjectDTO> evaluationDetailProject) {
        this.evaluationDetailProject = evaluationDetailProject;
    }
}
