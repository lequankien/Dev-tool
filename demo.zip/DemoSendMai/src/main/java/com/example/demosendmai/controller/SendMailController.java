package com.example.demosendmai.controller;

import com.example.demosendmai.service.SendMailCustom;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/sendMail")
public class SendMailController {
    private final SendMailCustom sendMailCustom;

    public SendMailController(SendMailCustom sendMailCustom) {
        this.sendMailCustom = sendMailCustom;
    }

    @PostMapping
    public ResponseEntity sendMai(@Param("evaluationId") Integer evaluationId, @Param("evaluationType") Integer evaluationType, HttpServletRequest request, Model model){
        return ResponseEntity.ok(sendMailCustom.SendMailToEvaluationPerson(evaluationId,request,model,evaluationType));
    }
}


//<span th:text="${}><span/>