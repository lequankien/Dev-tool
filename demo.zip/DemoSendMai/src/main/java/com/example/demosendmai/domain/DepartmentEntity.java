package com.example.demosendmai.domain;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "DEPARTMENT")
public class DepartmentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DEPARTMENT_ID")
    private Integer departmentId;

    @Column(name = "CODE")
    private String code;

    @Column(name = "NAME")
    private String departmentName;

    @Column(name = "PARENT_ID")
    private Integer parentID;

    @Column(name = "PARENT_CODE")
    private String parentCode;


}
