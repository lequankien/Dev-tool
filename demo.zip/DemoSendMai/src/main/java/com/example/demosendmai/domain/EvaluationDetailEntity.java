package com.example.demosendmai.domain;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "EVALUATION_DETAIL")
public class EvaluationDetailEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EVALUATION_DETAIL_ID")
    private Integer evaluationDetailId;

    @Column(name = "EVALUATION_ID")
    private Integer evaluationId;

    @Column(name = "EVALUATION_DEPARTMENT")
    private String evaluationDepartment;

    @Column(name = "ASSESSED_DEPARTMENT")
    private String assessedDepartment;

    @Column(name = "EVALUATION_PERSON")
    private String evaluationPerson;

    @Column(name = "ASSESSED_PERSON")
    private String assessedPerson;

    @Column(name = "EVALUATION_DETAIL_STATUS")
    private Integer evaluationDetailStatus;

}
