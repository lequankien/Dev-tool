package com.example.demosendmai.domain;

import lombok.Data;

import javax.persistence.*;
import java.time.Instant;
@Data
@Entity
@Table(name = "EVALUATION")
public class EvaluationEntity {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column(name = "EVALUATION_ID")
    private Integer evaluationId;

    @Column(name = "EVALUATION_NAME")
    private String evaluationName;

    @Column(name = "EVALUATION_STATUS")
    private Integer evaluationStatus;

    @Column(name = "DUA_DATE")
    private Instant dueDate;

    @Column(name = "CREATED_BY")
    private Integer createdBy;

    @Column(name = "DESCRIPTION")
    private Integer description;

    @Column(name = "EVALUATION_TYPE")
    private String evaluationType;


}
