package com.example.demosendmai.domain;


import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "EVALUATION_PROJECT")
public class EvaluationProjectEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EVALUATION_DETAIL_PROJECT_ID")
    private Integer evaluationDetailProjectId;

    @Column(name = "EVALUATION_DETAIL_ID")
    private Integer evaluationDetailId;

    @Column(name = "PROJECT_NAME")
    private String projectName;

    @Column(name = "PROJECT_STATUS")
    private Integer projectStatus;

    @Column(name = "EVALUATION_PERSON")
    private String evaluationPerson;

    @Column(name = "ASSESSED_PERSON")
    private String assessedPerson;


}
