package com.example.demosendmai.domain;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "JHI_USER")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "LOGIN")
    private String login;

    @Column(name = "PASSWORD_HASH")
    private String passwordHash;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "ACTIVATED")
    private Integer activated;

    @Column(name = "LANG_KEY")
    private String langKey;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "EMAIL")
    private String email;

}
