package com.example.demosendmai.repository;

import com.example.demosendmai.domain.DepartmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

public interface DepartmentRepository extends JpaRepository<DepartmentEntity, Integer> {
    @Query("select d.departmentName from DepartmentEntity d where d.code =:code")
    String findDepartmentNameByCode(String code);

}
