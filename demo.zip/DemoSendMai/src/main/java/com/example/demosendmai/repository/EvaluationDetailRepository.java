package com.example.demosendmai.repository;

import com.example.demosendmai.domain.EvaluationDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

public interface EvaluationDetailRepository extends JpaRepository<EvaluationDetailEntity, Integer> {
    @Query("select ed.evaluationPerson from EvaluationDetailEntity ed where ed.evaluationId =:evaluationId")
    String findEvaluationPersonByEvaluationId(@Param("evaluationId") Integer evaluationId);
    @Query("select ed.assessedPerson from EvaluationDetailEntity ed where ed.evaluationId =:evaluationId")
    String findAssessedPersonByEvaluationId(@Param("evaluationId") Integer evaluationId);
    @Query("select ed.evaluationDepartment from EvaluationDetailEntity ed where ed.evaluationId =:evaluationId")
    String findEvaluationDepartmentByEvaluationId(@Param("evaluationId") Integer evaluationId);
    @Query("select ed.assessedDepartment from EvaluationDetailEntity ed where ed.evaluationId =:evaluationId")
    String findAssessedDepartmentByEvaluationId(@Param("evaluationId") Integer evaluationId);

    @Query("select ed.evaluationDetailId from EvaluationDetailEntity ed where ed.evaluationId =:evaluationId")
    Integer findEvaluationDetailIdByEvaluationId(@Param("evaluationId") Integer evaluationId);

}
