package com.example.demosendmai.repository;

import com.example.demosendmai.domain.EvaluationProjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EvaluationProjectRepository extends JpaRepository<EvaluationProjectEntity, Integer>, CrudRepository<EvaluationProjectEntity, Integer> {
    @Query("SELECT ep.evaluationPerson FROM EvaluationProjectEntity ep WHERE ep.evaluationDetailProjectId =:evaluationDetailProjectId")
    String findEvaluationPersonByEvaluationDetailProjectId(Integer evaluationDetailProjectId);

    @Query("SELECT ep.projectName FROM EvaluationProjectEntity ep WHERE ep.evaluationDetailProjectId =:evaluationDetailProjectId")
    String findProjectNameByEvaluationDetailProjectId(Integer evaluationDetailProjectId);
    @Query("SELECT ep.evaluationDetailProjectId FROM EvaluationProjectEntity ep WHERE ep.evaluationDetailId =:evaluationDetailId")
    List<Integer> findEvaluationDetailProjectIdByEvaluationDetailId (Integer evaluationDetailId);


    @Query("SELECT ep.assessedPerson FROM EvaluationProjectEntity ep WHERE ep.evaluationDetailProjectId =:evaluationDetailProjectId")
    String findAssessedPersonByEvaluationDetailProjectId(Integer evaluationDetailProjectId);

}
