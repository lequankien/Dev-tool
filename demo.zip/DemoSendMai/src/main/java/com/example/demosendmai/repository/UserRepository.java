package com.example.demosendmai.repository;

import com.example.demosendmai.domain.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {
    @Query("select u.firstName from UserEntity u where u.email =:email")
    String findNameByEmail(@Param("email") String email);
}
