package com.example.demosendmai.service;

import com.example.demosendmai.DTO.DetailProjectDTO1;
import com.example.demosendmai.DTO.ListEmailReceiverDTO1;
import com.example.demosendmai.DTO.ListEmailReceiverDTO2;
import com.example.demosendmai.DTO.ListEvaluationDetailProjectDTO;
import com.example.demosendmai.DTO.SendToEvaluationPersonDTO;
import com.example.demosendmai.Utill.SiteURLUtil;
import com.example.demosendmai.domain.EvaluationDetailEntity;
import com.example.demosendmai.repository.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import javax.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.*;


@Service

public class SendMailCustom {
    @Autowired
    private  SendMailService sendMailService;
    @Autowired
    private  UserRepository userRepository;
    @Autowired
    private  EvaluationDetailRepository evaluationDetailRepository;

    @Autowired
    private  EvaluationRepository evaluationRepository;

    @Autowired
    private  DepartmentRepository departmentRepository;

    @Autowired
    private EvaluationProjectRepository evaluationProjectRepository;


    public ResponseEntity SendMailToEvaluationPerson(Integer evaluationId, HttpServletRequest request, Model model, Integer evaluationType){
        EvaluationDetailEntity entity = new EvaluationDetailEntity();
        ObjectMapper objectMapper = new ObjectMapper();
  /*     */ String evaluationPerson = evaluationDetailRepository.findEvaluationPersonByEvaluationId(evaluationId);
 /*     */  String assessedPerson = evaluationDetailRepository.findAssessedPersonByEvaluationId(evaluationId);
        String evaluationDepartment = evaluationDetailRepository.findEvaluationDepartmentByEvaluationId(evaluationId);
        String assessedDepartment = evaluationDetailRepository.findAssessedDepartmentByEvaluationId(evaluationId);
        String evaluationTypeName = evaluationRepository.findEvaluationTypeNameByEvaluationId(evaluationId);
        String evaluationDepartmentName = departmentRepository.findDepartmentNameByCode(evaluationDepartment);
        String assessedDepartmentName = departmentRepository.findDepartmentNameByCode(assessedDepartment);
        String evaluationName = evaluationRepository.findEvaluationNameByEvaluationId(evaluationId);
        Integer evaluationDetailId = evaluationDetailRepository.findEvaluationDetailIdByEvaluationId(evaluationId);
        List<Integer> evaluationDetailProjectId = evaluationProjectRepository.findEvaluationDetailProjectIdByEvaluationDetailId(evaluationDetailId);
        Instant dueDate = evaluationRepository.findDueDateByEvaluationId(evaluationId);
        //Map<String,Map<List<ListEmailReceiverDTO1>,List<ListEmailReceiverDTO2>>>  map = new HashMap<>();
        try{
           // Map<List<ListEmailReceiverDTO1>,List<ListEmailReceiverDTO2>> map3 = new HashMap<>();
            List<ListEmailReceiverDTO1> listEvaluationPerson = new ArrayList<>();
            List<ListEmailReceiverDTO2> listAssessedPerson = new ArrayList<>();
            List<ListEvaluationDetailProjectDTO> listEvaluationDetailProjectDTOS = new ArrayList<>();
            SendToEvaluationPersonDTO requestDTO = new SendToEvaluationPersonDTO();
            requestDTO.setEvaluationPerson(listEvaluationPerson);
            requestDTO.setAssessedPerson(listAssessedPerson);
            requestDTO.setEvaluationDepartment(evaluationDepartment);
            requestDTO.setAssessedDepartment(assessedDepartment);
            requestDTO.setEvaluationDepartmentName(evaluationDepartmentName);
            requestDTO.setAssessedDepartmentName(assessedDepartmentName);
            requestDTO.setEvaluationType(evaluationTypeName);
            requestDTO.setEvaluationName(evaluationName);
            requestDTO.setDueDate(String.valueOf(dueDate));
            requestDTO.setEvaluationDetailProject(listEvaluationDetailProjectDTOS);
                String accessLink = SiteURLUtil.getSiteURL(request) +"/" +evaluationId;
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            if(evaluationType == 1){
                for(Integer a:evaluationDetailProjectId ) {
                    DetailProjectDTO1 dto1 = new DetailProjectDTO1();
                    String projectNameOfProject = evaluationProjectRepository.findProjectNameByEvaluationDetailProjectId(a);
                    String evaluationPersonOfProject = evaluationProjectRepository.findEvaluationPersonByEvaluationDetailProjectId(a);
                    String assessedPersonOfProject = evaluationProjectRepository.findAssessedPersonByEvaluationDetailProjectId(a);
                    List<ListEmailReceiverDTO1> listEvaluationPersonOfProject = new ArrayList<>();
                    List<ListEmailReceiverDTO1> listEmailReceiverDTOS = objectMapper.readValue(evaluationPersonOfProject, new TypeReference<>() {});
                    for(ListEmailReceiverDTO1 item : listEmailReceiverDTOS){
                        ListEmailReceiverDTO1 dto = new ListEmailReceiverDTO1();
                        dto.setId(item.getId());
                        dto.setName(item.getName());
                        dto.setEmail(item.getEmail());
                        listEvaluationPersonOfProject.add(dto);
                    }
                    List<ListEmailReceiverDTO2> listAssessedPersonOfProject = new ArrayList<>();
                    List<ListEmailReceiverDTO2> listEmailReceiverDTOS1 = objectMapper.readValue(assessedPersonOfProject, new TypeReference<>() {});
                    for(ListEmailReceiverDTO2 item2 : listEmailReceiverDTOS1){
                          ListEmailReceiverDTO2 dto = new ListEmailReceiverDTO2();
                          dto.setId(item2.getId());
                          dto.setName(item2.getName());
                          dto.setEmail(item2.getEmail());
                          listAssessedPersonOfProject.add(dto);
                      }
                    ListEvaluationDetailProjectDTO projectDetailDTO = new ListEvaluationDetailProjectDTO();
                    projectDetailDTO.setProjectName(projectNameOfProject);
                    projectDetailDTO.setEvaluationPersonOfProject(listEvaluationPersonOfProject);
                    projectDetailDTO.setAssessedPersonOfProject(listAssessedPersonOfProject);
                    listEvaluationDetailProjectDTOS.add(projectDetailDTO);
                }
            }
            if(evaluationType == 2){
                List<ListEmailReceiverDTO1> listEmailReceiverDTOS2 = objectMapper.readValue(evaluationPerson, new TypeReference<>() {});
                for(ListEmailReceiverDTO1 item1 : listEmailReceiverDTOS2){
                    ListEmailReceiverDTO1 dto = new ListEmailReceiverDTO1();
                     dto.setId(item1.getId());
                     dto.setName(item1.getName());
                     dto.setEmail(item1.getEmail());
                     listEvaluationPerson.add(dto);
                     sendMailService.sendEmailFromTemplateToEvaluation(item1.getEmail(), requestDTO, "send_mail_truong_thanh", "title.name",accessLink);
                }
                List<ListEmailReceiverDTO2> listEmailReceiverDTOS3 = objectMapper.readValue(assessedPerson, new TypeReference<>() {});
                for(ListEmailReceiverDTO2 item2 : listEmailReceiverDTOS3){
                    ListEmailReceiverDTO2 dto2 = new ListEmailReceiverDTO2();
                    dto2.setId(item2.getId());
                    dto2.setName(item2.getName());
                    dto2.setEmail(item2.getEmail());
                    listAssessedPerson.add(dto2);
                    sendMailService.sendEmailFromTemplateToEvaluation(item2.getEmail(), requestDTO, "send_mail_truong_thanh", "title.name",accessLink);
                }
            }
        }catch (JsonMappingException e){
            e.printStackTrace();
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }
        return ResponseEntity.ok("check Email");
    }

}
