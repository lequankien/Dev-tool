package com.example.demosendmai.service;

import com.example.demosendmai.DTO.ListEmailReceiverDTO1;
import com.example.demosendmai.DTO.ListEmailReceiverDTO2;
import com.example.demosendmai.DTO.SendToEvaluationPersonDTO;
import com.example.demosendmai.domain.EvaluationDetailEntity;
import com.example.demosendmai.domain.UserEntity;
import com.example.demosendmai.repository.DepartmentRepository;
import com.example.demosendmai.repository.EvaluationDetailRepository;
import com.example.demosendmai.repository.EvaluationRepository;
import com.example.demosendmai.repository.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.util.StringUtils;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Service
public class SendMailService {
    private final Logger log = LoggerFactory.getLogger(SendMailService.class);
    @Value("${spring.mail.username}")
    private String fromEmail;
    @Value("${spring.mail.ITDepartment}")
    private String ITDepartment;


    private final JavaMailSender javaMailSender;

    private final MessageSource messageSource;

    private final SpringTemplateEngine templateEngine;

    public SendMailService(JavaMailSender javaMailSender, MessageSource messageSource, SpringTemplateEngine templateEngine) {
        this.javaMailSender = javaMailSender;
        this.messageSource = messageSource;
        this.templateEngine = templateEngine;

    }



    /*@Async
    public void sendEmail1(String to, String resetPasswordLink) {

        // Prepare message using a Spring helper
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage, StandardCharsets.UTF_8.name());
            message.setTo(to);
            message.setFrom(fromEmail);
            message.setSubject("Thư xác nhận bạn quên mật khẩu:");

            // find name by email
            String name = userRepository.findNameByEmail(to);

            Context context = new Context();
            context.setVariable("name", name);
            context.setVariable("link", resetPasswordLink);
            String content = templateEngine.process("mail/request-forgot-password.html", context);
            message.setText(content, true);
            javaMailSender.send(mimeMessage);
            log.debug("Sent email to User '{}'", to);
        } catch (MailException | MessagingException e) {
            log.warn("Email could not be sent to user '{}'", to, e);
        }
    }*/

    @Async
    public void sendEmail2(String to, String subject, String content, boolean isMultipart, boolean isHtml) {
        log.debug(
                "Send email[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}",
                isMultipart,
                isHtml,
                to,
                subject,
                content
        );

        // Prepare message using a Spring helper
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, StandardCharsets.UTF_8.name());
            message.setTo(to);
            message.setFrom(fromEmail);
            message.setSubject(subject);
            message.setText(content, isHtml);
            javaMailSender.send(mimeMessage);
            log.debug("Sent email to User '{}'", to);
        } catch (MailException | MessagingException e) {
            log.warn("Email could not be sent to user '{}'", to, e);
        }
    }

//    public void sendEmailFromTemplate(UserEntity user, String templateName, String titleKey) {
//        if (user.getEmail() == null) {
//            log.debug("Email doesn't exist for user '{}'", user.getLogin());
//            return;
//        }
//        Locale locale = Locale.forLanguageTag(user.getLangKey());
//        Context context = new Context(locale);
//        context.setVariable(USER, user);
//        context.setVariable(BASE_URL, fromEmail);
//        String content = templateEngine.process(templateName, context);
//        String subject = messageSource.getMessage(titleKey, null, locale);
//        sendEmail2(user.getEmail(), subject, content, false, true);
//    }
    @Async
    public void sendEmailFromTemplateToEvaluation(String to, SendToEvaluationPersonDTO request, String templateName, String titleKey, String accessLink) {
        /*if (user.getEmail() == null) {
            log.debug("Email doesn't exist for user '{}'", user.getLogin());
            return;
        }*/
        UserEntity user = new UserEntity();
        Locale locale;
        if (!StringUtils.isEmpty(user.getLangKey()))
            locale = Locale.forLanguageTag(user.getLangKey());
        else locale = Locale.forLanguageTag("vi");
        Context context = new Context();
        //context.setVariable("projectName",);
        context.setVariable("assessedPerson", request.getAssessedPerson() );
        context.setVariable("evaluationPerson", request.getEvaluationPerson());
        context.setVariable("evaluationDepartment", request.getEvaluationDepartment());
        context.setVariable("evaluationDepartmentName", request.getEvaluationDepartmentName());
        context.setVariable("assessedDepartment",request.getAssessedDepartment());
        context.setVariable("assessedDepartmentName",request.getAssessedDepartmentName());
        context.setVariable("evaluationType",request.getEvaluationType());
        context.setVariable("evaluationName",request.getEvaluationName());
        context.setVariable("dueDate",request.getDueDate());
        context.setVariable("description",request.getDescription());
        context.setVariable("accessLink", accessLink);
        context.setVariable("ITDepartmentPerson", ITDepartment);
        context.setVariable("projectDetail", request.getEvaluationDetailProject());
        String content = templateEngine.process(templateName, context);
        String subject = "DG-Portal thông báo đợt đánh giá" + request.getEvaluationName();
        sendEmail2(to, subject, content, false, true);

    }




   /* @Async
    public void sendActivationEmail(UserEntity user) {
        log.debug("Sending activation email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/activationEmail", "email.activation.title");
    }

    @Async
    public void sendCreationEmail(UserEntity user) {
        log.debug("Sending creation email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/creationEmail", "email.activation.title");
    }

    @Async
    public void sendPasswordResetMail(UserEntity user) {
        log.debug("Sending password reset email to '{}'", user.getEmail());
        sendEmailFromTemplate(user, "mail/passwordResetEmail", "email.reset.title");
    }*/
}
